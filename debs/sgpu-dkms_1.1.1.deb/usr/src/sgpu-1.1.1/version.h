/*
 * Copyright © 2022 Moore Threads Inc. All rights reserved.
 */

#pragma once
#ifndef VERSION_H
#define VERSION_H

#define SGPU_MAJOR_VERSION   1
#define SGPU_MINOR_VERSION   1
#define SGPU_BUILD_VERSION   1
#endif
