/*
 *  Copyright © 2022 Moore Threads Inc. All rights reserved.
 *
 */

#include <linux/proc_fs.h>

#include "sgpu.h"

int sgpu_proc_ioctl(int code, void *argi, void *argo, void *data)
{
    return 0;
}
