/**
 * Copyright ©2020-2022 Moore Threads Technology Co., Ltd ("Moore Threads"). All rights reserved.
 *
 * This software ("this software and its documentations" or "the software") is
 * protected by Copyright and the information contained herein is confidential.
 *
 * The software contained herein is PROPRIETARY to Moore Threads and is being provided under the terms and 
 * conditions of a form of Moore Threads software license agreement by and
 * between Moore Threads and Licensee ("License Agreement") or electronically
 * accepted by Licensee. Notwithstanding any terms or conditions to
 * the contrary in the License Agreement, copy or disclosure
 * of the software to any third party without the express
 * written consent of Moore Threads is prohibited.
 *
 * NOTWITHSTANDING ANY TERMS OR CONDITIONS TO THE CONTRARY IN THE
 * LICENSE AGREEMENT, MOORE THREADS MAKES NO REPRESENTATION ABOUT ANY WARRANTIES, INCLUDING BUT NOT LIMITED TO THE
 * SUITABILITY OF THE SOFTWARE FOR ANY PURPOSE. IT IS
 * PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY OF ANY KIND.
 * MOORE THREADS DISCLAIMS ALL WARRANTIES WITH REGARD TO THE
 * SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY,
 * NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE.
 * NOTWITHSTANDING ANY TERMS OR CONDITIONS TO THE CONTRARY IN THE
 * LICENSE AGREEMENT, IN NO EVENT SHALL MOORE THREADS BE LIABLE FOR ANY
 * SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, OR ANY
 * DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
 * ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE
 * OF THE SOFTWARE.
 **/

#ifndef MTML_H_
#define MTML_H_

#ifdef __cplusplus
extern "C" {
#endif

#if defined(_MSC_VER)
    #ifdef MTML_EXPORT
        #define MTML_API __declspec(dllexport)
    #else
        #define MTML_API __declspec(dllimport)
    #endif
#else
    #define MTML_API __attribute__ ((visibility ("default")))
#endif

#if defined (__GNUC__)
    #define MTML_DEPRECATED(msg) __attribute__ ((deprecated(msg)))
#elif defined(_MSC_VER)
    #define MTML_DEPRECATED(msg) __declspec(deprecated(msg))
#else
    #define MTML_DEPRECATED(msg)
#endif

/** 
 * @mainpage notitle
 * 
 * @section desc Basic concepts
 *
 * @subsection supported_platforms Supported platforms
 * <table style="margin-left:10px;">
 * <tr><th>CPU architecture<th>OS
 * <tr><td>x86_64<td>Ubuntu 20.04, UOS 20, Kylin V10, and Windows 10 Pro 21H2
 * <tr><td>AArch64<td>Kylin V10 SP1
 * </table>
 * 
 * @subsection opaque Opaque data types
 * The MTML library works with several core opaque data types. Each data type represents a specific functional entity that a user can interact with. 
 * Most functions defined below take one or more opaque objects as its input parameters. Therefore, it is important for a
 * user to have a good understanding of them.
 * - \b MtmlLibrary represents the MTML library itself and plays as the entry point to access and create other opaque objects.
 * - \b MtmlSystem represents the system environment in which the library is running.
 * - \b MtmlDevice represents the Moore Threads device (including virtual devices) that is installed in the system. 
 * - \b MtmlGpu represents the graphic unit of a Moore Threads device, which is responsible for the 3D and compute workloads.
 * - \b MtmlMemory represents the memory units that reside on a Moore Threads device.
 * - \b MtmlVpu represents the video codec unit of a Moore Threads device which handles the video encoding and decoding task.
 * 
 * The relationship among the above opaque data types is hierarchical, which means some type 'contains' other types. The hierarchy of opaque data types 
 * mentioned above can be summarized as follows. \n
 \verbatim
 Library 
    |--- System 
    |--- Device 
           |--- GPU
           |--- Memory
           |--- VPU
 \endverbatim
 * 
 * 
 * @subsection init Initialization and freeing
 * It is important to properly initialize an opaque object before using it as an argument to invoke other functions. The hierarchical 
 * relationships among opaque data types determine the initialization order of them. For example, to initialize an MtmlGpu struct, a user should 
 * firstly initialize a MtmlLibrary struct, then initialize the MtmlDevice struct from the MtmlLibrary, and finally initialize the MtmlGpu
 * struct from the MtmlDevice struct.
 * 
 * Initializing an opaque object is completed by invoking an mtml***Init***() function. When an opaque object is not needed any longer, it's 
 * the user's responsibility to instruct the MTML library to release the underlying resources of the opaque object by calling the corresponding 
 * mtml***Free***() function. Due to the hierarchical relationships among opaque data types, it is important to release the opaque data 
 * pointers in reversed order as regards to their initialization order.
 * 
 * 
 * @subsection virtualization Virtualization
 * It is recommended to build some fundamental concepts before using the device virtualization management feature provided by the MTML library.
 * There are two major functionalities with regards to the virtualization feature: virtualization type management and virtual device management. 
 * More specifically, several concepts shall be introduced:
 * - \b Virtualizability - This is a concept used to describe whether a physical device supports virtualization. Therefore, a virtualizable device is
 * defined as a physical device from which virtual resources can be created.
 * - \b Virtualization \b Type - A virtualization type is a specification template that confines virtual resource (for example, device memory) allocation. 
 * Typically, a virtualizable device supports several virtualization types, therefore virtual devices (see below) with corresponding specifications can 
 * be created.
 * - \b Virtual \b Device - A virtual device is created from a virtualizable device according to a specified virtualization type. It is key to
 * remember that a virtual device is a a host-only concept. That means you can initialize an MtmlDevice opaque object that represents a virtual device
 * only if the MTML library is running in a virtualization-enabled host environment. 
 * 
 * 
 * @subsection codec Codec session
 * A codec session is an independent encoding/decoding process of a video stream. The concurrent codec sessions number that can be supported by 
 * the video codec unit of a Moore Threads device is called \b codec \b capacity. The \b decodeCapacity and \b encodeCapacity represent 
 * the maximum limit of concurrent decoder sessions and encoder sessions, respectively.
 * 
 * Each codec session is identifiable from a unique integral value, called \b session \b ID. For decoder sessions, the session ID ranges
 * from \b 0 ~ \b (decodeCapacity-1), while it ranges from \b 0 ~ \b (encodeCapacity-1) for encoder sessions.
 * 
 * Another important aspect of a codec session is its \b state. The definition of the state of a codec session is as follows:
 * - \b Inactive \b (Idle): There is no video workload assigned to this session.
 * - \b Active: A video encoding/decoding workload is assigned to this session.
 * At any given time point, the state of a codec session can be queried. If a codec session is in an active state, its metrics information
 * then can be queried.
 * 
 * Refer to the videoMonApp() sample in sample/basic/basic_sample.cpp for a workable sample code.
 */

/***************************************************************************************************/
/** @defgroup mtml1 Constant Definitions
 * This group introduces constant definitions.
 *  @{
 */
/***************************************************************************************************/

/**
 * Recommended buffer size in bytes that is guaranteed to be enough to hold the MTML library version string (including a null terminator).
 */
#define MTML_LIBRARY_VERSION_BUFFER_SIZE            32

/**
 * Recommended buffer size in bytes that is guaranteed to be enough to hold the driver version string (including a null terminator).
 */
#define MTML_DRIVER_VERSION_BUFFER_SIZE             80

/**
 * Recommended buffer size in bytes that is guaranteed to be enough to hold the device name string (including a null terminator).
 */
#define MTML_DEVICE_NAME_BUFFER_SIZE                32

/**
 * Recommended buffer size in bytes that is guaranteed to be enough to hold the UUID string of a device (including a null terminator).
 */
#define MTML_DEVICE_UUID_BUFFER_SIZE                48

/**
 * Recommended buffer size in bytes that is guaranteed to be enough to hold the MTBIOS version string (including a null terminator).
 */
#define MTML_DEVICE_MTBIOS_VERSION_BUFFER_SIZE      64

/**
 * @deprecated Renamed to \ref MTML_DEVICE_MTBIOS_VERSION_BUFFER_SIZE
 */
#define MTML_DEVICE_VBIOS_VERSION_BUFFER_SIZE       MTML_DEVICE_MTBIOS_VERSION_BUFFER_SIZE

/**
 *Recommended buffer size in bytes that is guaranteed to be enough to hold the device path string (including a null terminator).
 */
#define MTML_DEVICE_PATH_BUFFER_SIZE                64

/**
 * Recommended buffer size in bytes that is guaranteed to be enough to hold the PCI SBDF string of a device (including a null terminator).
 */
#define MTML_DEVICE_PCI_SBDF_BUFFER_SIZE            32

/**
 * Recommended buffer size in bytes that is guaranteed to be enough to hold the ID string of a virtualization type (including a null terminator).
 */
#define MTML_VIRT_TYPE_ID_BUFFER_SIZE               16

/**
 * Recommended buffer size in bytes that is guaranteed to be enough to hold the class string of a virtualization type (including a null terminator).
 */
#define MTML_VIRT_TYPE_CLASS_BUFFER_SIZE            32

 /**
  * Recommended buffer size in bytes that is guaranteed to be enough to hold the name string of a virtualization type (including a null terminator).
  */
#define MTML_VIRT_TYPE_NAME_BUFFER_SIZE             32

 /**
  * Recommended buffer size in bytes that is guaranteed to be enough to hold the API string of a virtualization type (including a null terminator).
  */
#define MTML_VIRT_TYPE_API_BUFFER_SIZE              16

/**
 * Format string for PCI BUS ID.
 */
#define MTML_DEVICE_PCI_BUS_ID_FMT                  "%08X:%02X:%02X.0"

/**
 * Recommended buffer size in bytes that is guaranteed to be enough to hold the the name string of a filepath (including a null terminator).
 */
#define MTML_LOG_FILE_PATH_BUFFER_SIZE              200 

/** 
 * Return values for MTML API calls. 
 */
typedef enum {
    MTML_SUCCESS = 0,               //!< The operation was successful.
    MTML_ERROR_DRIVER_NOT_LOADED,   //!< The Moore Threads driver is not loaded.
    MTML_ERROR_DRIVER_FAILURE,      //!< Access to the driver failed.
    MTML_ERROR_INVALID_ARGUMENT,    //!< One or more supplied arguments are invalid.
    MTML_ERROR_NOT_SUPPORTED,       //!< The requested operation is not available on the target device.
    MTML_ERROR_NO_PERMISSION,       //!< The current user does not have permission to operate.
    MTML_ERROR_INSUFFICIENT_SIZE,   //!< The space allocated by the user is insufficient to hold the requested data.
    MTML_ERROR_NOT_FOUND,           //!< A query to find a resource was unsuccessful.
    MTML_ERROR_INSUFFICIENT_MEMORY, //!< There is not enough system memory to finish the operation.
    MTML_ERROR_DRIVER_TOO_OLD,      //!< An operation is failed due to the installed driver is too old.
    MTML_ERROR_DRIVER_TOO_NEW,      //!< An operation is failed due to the installed driver is too new.
    MTML_ERROR_UNKNOWN = 999        //!< An internal unspecified error occurred.
} MtmlReturn;

/**
 * The brand of the device.
 */
typedef enum {
    MTML_BRAND_MTT = 0,         //!< MTT series.
    MTML_BRAND_UNKNOWN,         //!< An unknown brand.

    // Keep this on the last line.
    MTML_BRAND_COUNT            //!< The number of brands.
} MtmlBrandType;

/**
 * The video codec types.
 */
typedef enum {
    MTML_CODEC_TYPE_AVC   = 0,
    MTML_CODEC_TYPE_VC1   = 1,
    MTML_CODEC_TYPE_MPEG2 = 2,
    MTML_CODEC_TYPE_MPEG4 = 3,
    MTML_CODEC_TYPE_H263  = 4,
    MTML_CODEC_TYPE_DIV3  = 5,
    MTML_CODEC_TYPE_RV    = 6,
    MTML_CODEC_TYPE_AVS   = 7,
    MTML_CODEC_TYPE_RSVD1 = 8,  //!< Invalid value.
    MTML_CODEC_TYPE_THO   = 9,
    MTML_CODEC_TYPE_VP3   = 10,
    MTML_CODEC_TYPE_VP8   = 11,
    MTML_CODEC_TYPE_HEVC  = 12,
    MTML_CODEC_TYPE_VP9   = 13,
    MTML_CODEC_TYPE_AVS2  = 14,
    MTML_CODEC_TYPE_RSVD2 = 15, //!< Invalid value.
    MTML_CODEC_TYPE_AV1   = 16,

    // Keep this on the last line.
    MTML_CODEC_TYPE_COUNT
} MtmlCodecType;

/**
 * The video codec session states.
 */
typedef enum {
    MTML_CODEC_SESSION_STATE_UNKNOWN    = -1,
    MTML_CODEC_SESSION_STATE_IDLE       = 0,
    MTML_CODEC_SESSION_STATE_ACTIVE,

    // Keep this on the last line.
    MTML_CODEC_SESSION_STATE_COUNT
} MtmlCodecSessionState;

/**
 * The role of a virtualized device.
 */
typedef enum {
    MTML_VIRT_ROLE_NONE,                    //!< The device is not a virtual device or its virtualization role is unknown.
    MTML_VIRT_ROLE_HOST_VIRTDEVICE,         //!< The device is a virtual device instantiated from a virtualization
                                            //!< type of a physical device. This role is only reported in the host OS.

    // Keep this on the last line.
    MTML_VIRT_ROLE_COUNT,                   //!< The number of virtualization roles.
} MtmlVirtRole;

typedef enum {
    MTML_TOPOLOGY_INTERNAL = 0,     //!< Topology path within same card, for example devices on same S2000 card.
    MTML_TOPOLOGY_SINGLE = 1,       //!< Topology path that only need traverse a single PCIe switch.
    MTML_TOPOLOGY_MULTIPLE = 2,     //!< Topology path that need not traverse a host bridge.
    MTML_TOPOLOGY_HOSTBRIDGE = 3,   //!< Topology path that are connected to the same host bridge.
    MTML_TOPOLOGY_NODE = 4,         //!< Topology path that are connected to the same NUMA node but possibly multiple host bridges.
    MTML_TOPOLOGY_SYSTEM = 5,       //!< Topology path in the system.

 
} MtmlDeviceTopologyLevel;

/**
 * All supported log levels.
 */
typedef enum {
    MTML_LOG_LEVEL_OFF = 0,    //!< Logs at all level is disable.
    MTML_LOG_LEVEL_FATAL,      //!< Very severe error event that will presumably lead the application to abort.
    MTML_LOG_LEVEL_ERROR,      //!< Error information but will continue application to keep running.
    MTML_LOG_LEVEL_WARNING,    //!< Information representing errors in application but application will keep running.
    MTML_LOG_LEVEL_INFO,       //!< Mainly useful to represent current progress of application.
} MtmlLogLevel;
 
/***********************************/
/** @}
 */
/***********************************/



/***************************************************************************************************/
/** @defgroup mtml2 Functional Structure Definitions
 * This group introduces functional structures.
 *  @{
 */
/***************************************************************************************************/

/**
 * PCI information about a device.
 */
typedef struct {
    char sbdf[MTML_DEVICE_PCI_SBDF_BUFFER_SIZE];       //!< The tuple segment:bus:device.function PCI identifier (&amp; NULL terminator).
    unsigned int segment;                              //!< The PCI segment group(domain) on which the device's bus resides, 0 to 0xffffffff.
    unsigned int bus;                                  //!< The bus on which the device resides, 0 to 0xff.
    unsigned int device;                               //!< The device ID on the bus, 0 to 31.
    unsigned int pciDeviceId;                          //!< The combined 16-bit device ID and 16-bit vendor ID.
    unsigned int pciSubsystemId;                       //!< The 32-bit sub system device ID.
    unsigned int busWidth;                             //!< @deprecated This value set to zero.
    float pciMaxSpeed;                                 //!< The maximum link speed (transfer rate per lane) of the device. The unit is GT/s.
    float pciCurSpeed;                                 //!< The current link speed (transfer rate per lane) of the device. The unit is GT/s.
    unsigned int pciMaxWidth;                          //!< The maximum link width of the device.
    unsigned int pciCurWidth;                          //!< The current link width of the device.
    int rsvd[8];                                       //!< Reserved for future extension.
} MtmlPciInfo;

/** 
 * Codec utilization percentage on a device.
 */
typedef struct {
    unsigned int util;              //!< The codec's overall utilization rate over the sampling period.
    unsigned int period;            //!< The sampling period of time, in microseconds.
    unsigned int encUtil;           //!< The encoder utilization rate over the sampling period.
    unsigned int decUtil;           //!< The decoder utilization rate over the sampling period.
    int rsvd[2];                    //!< Reserved for future extension.
} MtmlCodecUtil;

/** 
 * Codec session metrics.
 */
typedef struct {
    unsigned int id;            //!< The unique identifier of the code session.
    unsigned int pid;           //!< The process ID. 0 represents an idle session, otherwise the session is considered active.
    unsigned int hResolution;   //!< The horizontal resolution in pixels.
    unsigned int vResolution;   //!< The vertical resolution in pixels.
    unsigned int frameRate;     //!< The number of frames per second.
    unsigned int bitRate;       //!< The number of bits per second.
    unsigned int latency;       //!< The codec latency in microseconds.
    MtmlCodecType codecType;    //!< Type of codec. For example, H.265 and AV1.
    int rsvd[4];                //!< Reserved for future extension.
} MtmlCodecSessionMetrics;

/**
 * The type of virtualization that describes the specification of a virtualized device.
 */
typedef struct {
    char id[MTML_VIRT_TYPE_ID_BUFFER_SIZE];         //!< The ID of the virtualization type. For example, mtgpu-2008.
    char name[MTML_VIRT_TYPE_NAME_BUFFER_SIZE];     //!< The name of the virtualization type. For example, mtgpu-8g.
    char api[MTML_VIRT_TYPE_API_BUFFER_SIZE];       //!< The API type of the virtualization type. For example, vfio-pci.
    int rsvd[18];                                   //!< Reserved for future extension
} MtmlVirtType;

/**
 * The property of a device.
 *
 * NOTE:
 * A physical device that does not support virtualization (for example, S10) might still be able to be used in pass-through manner.
 * For such device, its 'virtCap' field is '0 - non-virtualizable'.
 */
typedef struct {
    unsigned int virtCap : 1;       //!< This field indicates the virtualization capability of a device (whether a device supports to be 
                                    //!< virtualized) : 0 indicates non-virtualizable and 1 indicates virtualizable.
    unsigned int virtRole : 3;      //!< This field indicates the role that this device is playing in a virtualization-supported 
                                    //!< environment. Refer to \ref MtmlVirtRole.
    unsigned int rsvd : 28;         //!< Reserved for future extension.
    unsigned int rsvd2 : 32;        //!< Reserved for future extension.
} MtmlDeviceProperty;

/**
 * Configuration for the MTML logger.
 */
typedef struct {
    struct {
        MtmlLogLevel level;                             //!< Configures the level of logger.
        int rsvd[2];                                    //!< Reserved for future extensions.
    } consoleConfig;                                    //!< Logs are output to stdout.
    struct {
        MtmlLogLevel level;                             //!< Configures the level of logger.
        int rsvd[2];                                    //!< Reserved for future extensions.
    } systemConfig;                                     //!< Logs are output to syslog, which is supported only for Linux.                       
    struct {
        MtmlLogLevel level;                             //!< Configures the level of logger.
        char file[MTML_LOG_FILE_PATH_BUFFER_SIZE];      //!< Sets the file for log output. MTML will keep the file open if this field is set to a valid path.
                                                        //!< Sets it to an empty string in case a previously opened file needs to be closed.
        unsigned int size;                              //!< Sets max log size in file, which will be clean when it over size.
        int rsvd[2];                                    //!< Reserved for future extensions.
    } fileConfig;                                       //!< Logs are output to a user-specified file.
    struct {
        MtmlLogLevel level;                             //!< Configures the level of logger.
        void (*callback)(const char*, unsigned int);    //!< Callback will acquire all logs.
        int rsvd[2];                                    //!< Reserved for future extensions.
    } callbackConfig;                                   //!< Logs are output to a user-specified callback.
    int rsvd[8];                                        //!< Reserved for future extensions.
} MtmlLogConfiguration;

/* P2P capability status.*/
typedef enum {
    MTML_P2P_STATUS_OK = 0,
    MTML_P2P_STATUS_CHIPSET_NOT_SUPPORED,
    MTML_P2P_STATUS_GPU_NOT_SUPPORTED,
    MTML_P2P_STATUS_UNKNOWN
} MtmlDeviceP2PStatus;

/* P2P capability. */
typedef enum {
    MTML_P2P_CAPS_READ = 0,
    MTML_P2P_CAPS_WRITE
} MtmlDeviceP2PCaps;

/***********************************/
/** @}
 */
/***********************************/



/***************************************************************************************************/
/** @defgroup mtml3 Opaque Data Structure Definitions
 * This group introduces opaque data structures.
 *  @{
 */
/***************************************************************************************************/

/**
 * GPU opaque data structure.
 */
typedef struct MtmlGpu MtmlGpu;

/**
 * Memory opaque data structure.
 */
typedef struct MtmlMemory MtmlMemory;

/**
 * VPU opaque data structure.
 */
typedef struct MtmlVpu MtmlVpu;

/**
 * Device opaque data structure.
 */
typedef struct MtmlDevice MtmlDevice;

/**
 * System opaque data structure.
 */
typedef struct MtmlSystem MtmlSystem;

/**
 * Library opaque data structure.
 */
typedef struct MtmlLibrary MtmlLibrary;

/***********************************/
/** @}
 */
/***********************************/



/***************************************************************************************************/
/** @defgroup mtml4 Library Functions
 * This group introduces library functions.
 *  @{
 */
/***************************************************************************************************/

/**
 * Initializes an library opaque object and prepares resources. Upon success, the initialized object can be used for further 
 * access to other functions. An library opaque object is the top-level entry-point from which user code can 
 * access other functions provided by the MTML library.
 *
 * For all products.
 * 
 * The output data is allocated internally by the MTML library. Use \ref mtmlLibraryShutDown() to release its resources
 * when it is not needed any longer.
 * 
 * @param lib                                   [out] A double pointer to the library opaque object that is allocated and initialized.
 * 
 * @warning Providing this function with a \a lib that has already been initialized causes memory leak.
 * 
 * @return 
 *         - \ref MTML_SUCCESS                      if an library opaque object has been properly initialized.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT       if \a lib is NULL.
 *         - \ref MTML_ERROR_INSUFFICIENT_MEMORY    if the system is running out of memory.
 *         - \ref MTML_ERROR_DRIVER_FAILURE         if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_UNKNOWN                if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlLibraryInit(MtmlLibrary **lib);

/**
 * Shuts down a library opaque object that is previously initialized by \ref mtmlLibraryInit() and releases its resources.
 * This opaque object cannot be used with other functions any longer unless being initialized again.
 *
 * For all products. 
 *
 * @param lib                                   [in] A pointer to the library opaque object that needs to be shut down.
 * 
 * @return 
 *         - \ref MTML_SUCCESS                  if MTML has been properly shut down.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT   if \a lib is NULL.
 *         - \ref MTML_ERROR_UNKNOWN            if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlLibraryShutDown(MtmlLibrary *lib);

/**
 * Retrieves the version of the specified MtmlLibrary opaque data. 
 * 
 * For all products. 
 *
 * The version identifier is an alphanumeric string and null-terminator guaranteed.
 * 
 * @param lib                                  [in] The pointer to library opaque data.
 * @param version                              [out] The reference in which to return the version identifier.
 * @param length                               [in] The length of the buffer pointed by \a version. See \ref MTML_LIBRARY_VERSION_BUFFER_SIZE 
 *
 * @return
 *         - \ref MTML_SUCCESS                      if \a version has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT       if \a version or \a lib is NULL.
 *         - \ref MTML_ERROR_INSUFFICIENT_SIZE      if \a length is too small to hold the version string.
 *         - \ref MTML_ERROR_UNKNOWN                if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlLibraryGetVersion(const MtmlLibrary *lib, char* version, unsigned int length);

/**
 * Initializes a MtmlSystem opaque pointer that is bound to a library opaque object.
 * The output data is allocated internally by the MTML library. \ref mtmlLibraryFreeSystem() to release its resource
 * when it is not needed any longer.
 * 
 * For all products. 
 * 
 * The initialized MtmlSystem opaque object can be used with system-related functions.
 * 
 * @param lib                                  [in] The pointer to library opaque data.
 * @param sys                                  [out] The double pointer to the system opaque data that shall be allocated and initialized.
 * 
 * @warning Providing this function with a \a sys that has already been initialized causes memory leak.
 * 
 * @return
 *         - \ref MTML_SUCCESS                      if \a sys has been initialized.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT       if \a lib or \a sys is NULL.
 *         - \ref MTML_ERROR_INSUFFICIENT_MEMORY    if the system is running out of memory.
 *         - \ref MTML_ERROR_UNKNOWN                if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlLibraryInitSystem(const MtmlLibrary *lib, MtmlSystem **sys);

/**
 * Releases the resources managed by the MtmlSystem opaque object and makes it unusable.
 * 
 * For all products.
 * 
 * @param sys                                  [in] The pointer to the system opaque object that shall be freed.
 * @return
 *         - \ref MTML_SUCCESS                      if \a sys has been freed.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT       if \a sys is NULL.
 *         - \ref MTML_ERROR_UNKNOWN                if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlLibraryFreeSystem(MtmlSystem *sys);

 /**
 * Retrieves the number of devices that can be accessed by the library opaque object.
 * 
 * @param lib                                  [in] The pointer to the library opaque object.
 * @param count                                [out] The reference in which to return the number of accessible devices.
 * 
 * @return
 *         - \ref MTML_SUCCESS                  if \a count has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT   if \a count or \a lib is NULL.
 *         - \ref MTML_ERROR_UNKNOWN            if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlLibraryCountDevice(const MtmlLibrary *lib, unsigned int *count);

/**
 * Initializes a device opaque object to represent a device that is designated by its index. 
 * The index ranges from (0) to (deviceCount - 1), where deviceCount is retrieved from \ref mtmlLibraryCountDevice().
 * The output data is allocated internally by the MTML library. Use \ref mtmlLibraryFreeDevice() to release its resources
 * when it is not needed any longer.
 * 
 * For all products.
 *
 * The initialized device opaque object can be used with device-related functions.
 *
 * @param lib                                  [in] The pointer to the library opaque object.
 * @param index                                [in] The index of the target device.
 * @param dev                                  [out] The double pointer to the device opaque object that shall be allocated and initialized.
 * 
 * @warning Providing this function with a \a dev that has already been initialized causes memory leak.
 * 
 * @return
 *         - \ref MTML_SUCCESS                      if \a device has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT       if \a index is invalid, or either \a lib or \a dev is NULL.
 *         - \ref MTML_ERROR_NOT_FOUND              if no device with the specified \a index is found.
 *         - \ref MTML_ERROR_INSUFFICIENT_MEMORY    if the system is running out of memory.
 *         - \ref MTML_ERROR_DRIVER_FAILURE         if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_UNKNOWN                if any unexpected error occurred.
 *
 * @see mtmlLibraryCountDevice
 * 
 */
MtmlReturn MTML_API mtmlLibraryInitDeviceByIndex(const MtmlLibrary *lib, unsigned int index, MtmlDevice **dev);

/**
 * Initializes a device opaque object to represent a device that is designated by its UUID. See \ref mtmlDeviceGetUUID() for more information
 * about the device's UUID.
 * The output data is allocated internally by the MTML library. Use \ref mtmlLibraryFreeDevice() to release its resources
 * when it is not needed any longer.
 * 
 * For all products.
 *
 * The initialized device opaque object can be used with device-related functions.
 *
 * @param lib                                  [in] The pointer to the library opaque object.
 * @param uuid                                 [in] The UUID of the target device.
 * @param dev                                  [out] The double pointer to the device opaque object that shall be allocated and initialized.
 * 
 * @warning Providing this function with a \a dev that has already been initialized causes memory leak.
 * 
 * @return
 *         - \ref MTML_SUCCESS                      if \a device has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT       if \a library, \a uuid, or \a dev is NULL.
 *         - \ref MTML_ERROR_NOT_FOUND              if no device with the specified \a uuid is found.
 *         - \ref MTML_ERROR_INSUFFICIENT_MEMORY    if the system is running out of memory.
 *         - \ref MTML_ERROR_DRIVER_FAILURE         if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_UNKNOWN                if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlLibraryInitDeviceByUuid(const MtmlLibrary *library, const char *uuid, MtmlDevice **dev);

/**
 * Initializes a device opaque object to represent a device that is designated by its PCI Sbdf.
 * The PCI Sbdf format like 00000000:3a:00.0 refer to \ref MtmlPciInfo::sbdf.
 * The output data is allocated internally by the MTML library. Use \ref mtmlLibraryFreeDevice() to release its resources
 * when it is not needed any longer.
 *
 * For all products.
 *
 * @param lib                                  [in] The pointer to the library opaque object.
 * @param pciSbdf                              [in] The PCI bus id of the target device.
 * @param device                               [out] Reference in which to return the device handle.
 *
 * @return
 *         - \ref MTML_SUCCESS                      if \a device has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT       if \a pciSbdf is invalid, \a library or \a dev is NULL.
 *         - \ref MTML_ERROR_INSUFFICIENT_MEMORY    if the system is running out of memory.
 *         - \ref MTML_ERROR_NOT_FOUND              if no device with the specified \a pciSbdf is found.
 *         - \ref MTML_ERROR_UNKNOWN                on any unexpected error.
 */
MtmlReturn MTML_API mtmlLibraryInitDeviceByPciSbdf(const MtmlLibrary* lib, const char* pciSbdf, MtmlDevice** dev);

/**
 * Releases the resources managed by the device opaque object and makes it unusable.
 * 
 * For all products.
 * 
 * @param dev                                  [in] The pointer to the device opaque object that shall be freed.
 * 
 * @return
 *         - \ref MTML_SUCCESS                      if \a dev has been freed.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT       if \a dev is NULL.
 *         - \ref MTML_ERROR_NOT_SUPPORTED          if \a dev is a Virtual Device.
 *         - \ref MTML_ERROR_UNKNOWN                if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlLibraryFreeDevice(MtmlDevice *dev);

/***********************************/
/** @}
 */
/***********************************/



/***************************************************************************************************/
/** @defgroup mtml5 System Functions
 * This group introduces system functions.
 *  @{
 */
/***************************************************************************************************/

/**
 * Retrieves the version of the driver that is installed on the current platform.
 *
 * For all products.
 *
 * The version identifier is an alphanumeric string.
 *
 * @param sys                                  [in] The pointer to the system opaque object.
 * @param version                              [out] The reference in which to return the version identifier.
 * @param length                               [in] The buffer size pointed by \a version. See \ref MTML_DRIVER_VERSION_BUFFER_SIZE.
 *
 * @return
 *         - \ref MTML_SUCCESS                    if \a version has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT     if \a sys or \a version is NULL.
 *         - \ref MTML_ERROR_INSUFFICIENT_SIZE    if \a length is too small.
 *         - \ref MTML_ERROR_UNKNOWN              if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlSystemGetDriverVersion(const MtmlSystem *sys, char *version, unsigned int length);

/***********************************/
/** @}
 */
/***********************************/


/***************************************************************************************************/
/** @defgroup mtml6 Device Functions
 * This group introduces device functions.
 *  @{
 */
/***************************************************************************************************/

/**
 * Initializes a GPU opaque object to represent a specific graphic core on the target device that is designated by its index.
 * The output data is allocated internally by the MTML library. Use \ref mtmlDeviceFreeGpu() to release its resources
 * when it is not needed any longer.
 * 
 * For all products.
 *
 * The initialized GPU opaque object can be used with GPU-related functions.
 *
 * @param dev                                  [in] The pointer to the device opaque object.
 * @param gpu                                  [out] The double pointer to the GPU opaque object that shall be allocated and initialized.
 * 
 * @warning Providing this function with a \a gpu that has already been initialized causes memory leak.
 * 
 * @return
 *         - \ref MTML_SUCCESS                      if \a gpu has been initialized successfully.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT       if \a dev or \a gpu is NULL.
 *         - \ref MTML_ERROR_INSUFFICIENT_MEMORY    if the system is running out of memory.
 *         - \ref MTML_ERROR_UNKNOWN                if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceInitGpu(const MtmlDevice *dev, MtmlGpu **gpu);

/**
 * Releases the resources managed by the GPU opaque object and makes it unusable.
 *  * For all products.
 * 
 * @param gpu                                  [in] The pointer to the GPU opaque object that shall be freed.
 * 
 * @return
 *         - \ref MTML_SUCCESS                      if \a gpu has been freed.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT       if \a gpu is NULL.
 *         - \ref MTML_ERROR_UNKNOWN                if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceFreeGpu(MtmlGpu *gpu);

/**
 * Initializes a memory opaque object to represent the memory on the target device.
 * The output data is allocated internally by the MTML library. Use \ref mtmlDeviceFreeMemory() to release its resources
 * when it is not needed any longer.
 * 
 * For all products.
 *
 * The initialized memory opaque object can be used with memory-related functions.
 *
 * @param dev                                  [in] The pointer to the device opaque object.
 * @param mem                                  [out] The double pointer to the memory opaque object that shall be allocated and initialized.
 * 
 * @warning Providing this function with a \a mem that has already been initialized causes memory leak.
 * 
 * @return
 *         - \ref MTML_SUCCESS                      if \a mem has been initialized successfully.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT       if \a dev or \a mem is NULL.
 *         - \ref MTML_ERROR_INSUFFICIENT_MEMORY    if the system is running out of memory.
 *         - \ref MTML_ERROR_UNKNOWN                if any unexpected error occurred.
 *
 */
MtmlReturn MTML_API mtmlDeviceInitMemory(const MtmlDevice *dev, MtmlMemory **mem);

/**
 * Releases the resources managed by the memory opaque object and makes it unusable.
 * 
 * For all products.
 * 
 * @param mem                                  [in] The pointer to the memory opaque object that shall be freed.
 * 
 * @return
 *         - \ref MTML_SUCCESS                      if \a mem has been freed.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT       if \a mem is NULL.
 *         - \ref MTML_ERROR_UNKNOWN                if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceFreeMemory(MtmlMemory *mem);

/**
 * Initializes a VPU opaque object to represent the video codec on the target device.
 * The output data is allocated internally by the MTML library. Use \ref mtmlDeviceFreeVpu() to release its resources
 * when it is not needed any longer.
 * 
 * For all products.
 *
 * The initialized VPU opaque object can be used with codec-related functions.
 *
 * @param dev                                  [in] The pointer to the device opaque object.
 * @param vpu                                  [out] The double pointer to the memory opaque object that shall be allocated and initialized.
 * 
 * @warning Providing this function with a \a vpu that has already been initialized causes memory leak.
 * 
 * @return
 *         - \ref MTML_SUCCESS                      if \a vpu has been successfully initialized.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT       if \a dev or \a vpu is NULL.
 *         - \ref MTML_ERROR_DRIVER_FAILURE         if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_INSUFFICIENT_MEMORY    if the system is running out of memory.
 *         - \ref MTML_ERROR_UNKNOWN                if any unexpected error occurred.
 *
 */
MtmlReturn MTML_API mtmlDeviceInitVpu(const MtmlDevice *dev, MtmlVpu **vpu);

/**
 * Releases the resources managed by the VPU opaque object and makes it unusable.
 * 
 * For all products.
 * 
 * @param vpu                                  [in] The pointer to the VPU opaque object that shall be freed.
 * 
 * @return
 *         - \ref MTML_SUCCESS                      if \a vpu has been freed.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT       if \a vpu is NULL.
 *         - \ref MTML_ERROR_UNKNOWN                if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceFreeVpu(MtmlVpu *vpu);

/**
 * Retrieves the index associated with the specified device.
 * 
 * For all products.
 *
 * @param dev                                  [in] The pointer to the device opaque object.
 * @param index                                [out] The index of the target device.
 *
 * @return
 *         - \ref MTML_SUCCESS                 if \a index has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT  if \a dev or \a index is NULL.
 *         - \ref MTML_ERROR_NOT_SUPPORTED     if \a dev does not support to be accessed by \a index. For example, the host virtual device.
 *         - \ref MTML_ERROR_UNKNOWN           if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceGetIndex(const MtmlDevice *dev, unsigned int *index);

/**
 * Retrieves the UUID of a specified device. The UUID is a hexadecimal string in the 
 * form of xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx, where each 'x' is an ASCII character that represents a hexidecimal
 * digit. The UUID is globally unique for every single device thus can be used to identify different devices
 * physically.
 *
 * For all products.
 *
 *
 * @param dev                                  [in] The identifier of the target device.
 * @param uuid                                 [out] The reference in which to return the UUID.
 * @param length                               [in] The size of buffer pointed by \a uuid. See \ref MTML_DEVICE_UUID_BUFFER_SIZE.
 *
 * @return
 *         - \ref MTML_SUCCESS                 if \a uuid has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT  if \a dev or \a uuid is NULL.
 *         - \ref MTML_ERROR_INSUFFICIENT_SIZE if \a length is too small.
 *         - \ref MTML_ERROR_UNKNOWN           if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceGetUUID(const MtmlDevice *dev, char *uuid, unsigned int length);

/**
 * Retrieves the brand of a device.
 *
 * For all products. 
 *
 * @param dev                                  [in] The pointer to the target device.
 * @param type                                 [out] The reference in which to return the product brand type. See \ref MtmlBrandType.
 *
 * @return 
 *         - \ref MTML_SUCCESS                   if \a name has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT    if \a dev is invalid or \a type is NULL.
 *         - \ref MTML_ERROR_UNKNOWN             on any unexpected error.
 *         - \ref MTML_ERROR_DRIVER_FAILURE      if any error occurred when accessing the driver.
 */
MtmlReturn MTML_API mtmlDeviceGetBrand(const MtmlDevice *dev, MtmlBrandType *type);

/**
 * Retrieves the name of a device.
 *
 *
 * @param dev                                  [in] The pointer to the target device.
 * @param name                                 [out] The reference in which to return the product name.
 * @param length                               [in] The size of buffer pointed by \a name. See MTML_DEVICE_NAME_BUFFER_SIZE.
 *
 * @return
 *         - \ref MTML_SUCCESS                  if \a name has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT   if \a dev or \a name is NULL.
 *         - \ref MTML_ERROR_INSUFFICIENT_SIZE  if \a length is too small.
 *         - \ref MTML_ERROR_NOT_SUPPORTED      if \a dev is a virtual device.
 *         - \ref MTML_ERROR_DRIVER_FAILURE     if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD     if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW     if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN            if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceGetName(const MtmlDevice *dev, char *name, unsigned int length);

/**
 * Retrieves the PCI attributes of a device.
 * 
 * For all products.
 *
 * See \ref MtmlPciInfo for details on the available PCI information.
 *
 * @param dev                                  [in] The pointer to the target device.
 * @param pci                                  [out] The reference in which to return the PCI info.
 * 
 * @return
 *         - \ref MTML_SUCCESS                    if \a pci has been populated.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT     if \a dev or \a pci is NULL.
 *         - \ref MTML_ERROR_NOT_SUPPORTED        if \a dev is a virtual device.
 *         - \ref MTML_ERROR_DRIVER_FAILURE       if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_UNKNOWN              if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceGetPciInfo(const MtmlDevice *dev, MtmlPciInfo *pci);

/**
 * Retrieves the power usage for a device in milliwatts (mW) and its associated circuitry.
 *
 *
 * @param dev                                  [in] The pointer to the target device.
 * @param power                                [out] The reference in which to return the power usage information.
 * 
 * @return
 *         - \ref MTML_SUCCESS                   if \a power has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT    if \a dev or \a power is NULL.
 *         - \ref MTML_ERROR_NOT_SUPPORTED       if the operation is not supported.
 *         - \ref MTML_ERROR_DRIVER_FAILURE      if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD      if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW      if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN             if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceGetPowerUsage(const MtmlDevice *dev, unsigned int *power);

/**
 * Retrieves the GPU paths of a device.
 *
 * For all products.
 *
 * @param dev                                  [in] The pointer to the target device.
 * @param path                                 [out] The reference in which to return the target device path.
 * @param length                               [in] The size of buffer pointed by \a path. See #MTML_DEVICE_PATH_BUFFER_SIZE.
 *
 * @return
 *         - \ref MTML_SUCCESS                 if \a path has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT  if \a dev or \a path is NULL.
 *         - \ref MTML_ERROR_NOT_SUPPORTED     if \a dev is a virtual device.
 *         - \ref MTML_ERROR_INSUFFICIENT_SIZE if \a length is too small.
 *         - \ref MTML_ERROR_UNKNOWN           if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceGetGpuPath(const MtmlDevice* dev, char* path,unsigned int length);

/**
 * Retrieves the primary paths of a device.
 *
 * For all products.
 *
 * @param dev                                  [in] The pointer to the target device.
 * @param path                                 [out] The reference in which to return the target device path.
 * @param length                               [in] The size of buffer pointed by \a path. See #MTML_DEVICE_PATH_BUFFER_SIZE.
 *
 * @return
 *         - \ref MTML_SUCCESS                 if \a path has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT  if \a dev or \a path is NULL.
 *         - \ref MTML_ERROR_INSUFFICIENT_SIZE if \a length is too small.
 *         - \ref MTML_ERROR_NOT_SUPPORTED     if \a dev is a virtual device.
 *         - \ref MTML_ERROR_DRIVER_FAILURE    if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_UNKNOWN           if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceGetPrimaryPath(const MtmlDevice* dev, char* path, unsigned int length);

/**
 * Retrieves the render paths of a device.
 *
 * For all products.
 *
 * @param dev                                  [in] The pointer to the target device.
 * @param path                                 [out] The reference in which to return the target device path.
 * @param length                               [in] The size of buffer pointed by \a path. See #MTML_DEVICE_PATH_BUFFER_SIZE.
 *
 * @return
 *         - \ref MTML_SUCCESS                 if \a path has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT  if \a dev or \a path is NULL.
 *         - \ref MTML_ERROR_INSUFFICIENT_SIZE if \a length is too small.
 *         - \ref MTML_ERROR_NOT_SUPPORTED     if \a dev is a virtual device.
 *         - \ref MTML_ERROR_DRIVER_FAILURE    if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_UNKNOWN           if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceGetRenderPath(const MtmlDevice* dev, char* path, unsigned int length);

/**
 * @deprecated Renamed to \ref mtmlDeviceGetMtBiosVersion as the name describes the situation more accurately.
 * 
 * Retrieves the version of the device's VBIOS.
 *
 * For all products.
 *
 * The version identifier is an alphanumeric string.
 *
 * @param dev                                  [in] The pointer to the target device.
 * @param version                              [out] The reference in which to return the version identifier.
 * @param length                               [in] The size of buffer pointed by \a version. See \ref MTML_DEVICE_VBIOS_VERSION_BUFFER_SIZE.
 *
 * @return
 *         - \ref MTML_SUCCESS                   if \a version has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT    if \a dev or \a version is NULL.
 *         - \ref MTML_ERROR_INSUFFICIENT_SIZE   if \a length is too small.
 *         - \ref MTML_ERROR_NOT_SUPPORTED       if \a dev is a virtual device.
 *         - \ref MTML_ERROR_DRIVER_FAILURE      if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_UNKNOWN             if any unexpected error occurred.
 */
MTML_DEPRECATED("use mtmlDeviceGetMtBiosVersion instead") 
MtmlReturn MTML_API mtmlDeviceGetVbiosVersion(const MtmlDevice* dev, char* version, unsigned int length);

/**
 * Retrieves the version of the device's MTBIOS firmware.
 *
 * For all products.
 *
 * The version identifier is an alphanumeric string.
 *
 * @param dev                                  [in] The pointer to the target device.
 * @param version                              [out] The reference in which to return the version identifier.
 * @param length                               [in] The size of buffer pointed by \a version. See \ref MTML_DEVICE_MTBIOS_VERSION_BUFFER_SIZE.
 *
 * @return
 *         - \ref MTML_SUCCESS                   if \a version has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT    if \a dev or \a version is NULL.
 *         - \ref MTML_ERROR_INSUFFICIENT_SIZE   if \a length is too small.
 *         - \ref MTML_ERROR_NOT_SUPPORTED       if \a dev is a virtual device.
 *         - \ref MTML_ERROR_DRIVER_FAILURE      if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD      if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW      if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN             if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceGetMtBiosVersion(const MtmlDevice* dev, char* version, unsigned int length);

/**
 * Retrieves the properties of a device.
 * 
 * For all products.
 *
 * @param dev                                  [in] The pointer to the target device.
 * @param prop                                 [out] The reference in which to return the target device properties.
 *
 * @return
 *         - \ref MTML_SUCCESS                 if \a prop has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT  if \a dev or \a prop is NULL.
 *         - \ref MTML_ERROR_DRIVER_FAILURE    if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_UNKNOWN           if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceGetProperty(const MtmlDevice *dev,  MtmlDeviceProperty *prop);

/**
 * Retrieves the number of fans on a device.
 *
 * For all discrete products with dedicated fans.
 *
 * @param dev                                  [in] The pointer of the target device.
 * @param count                                [out] The reference in which to return the fan count.
 *
 * @return
 *         - \ref MTML_SUCCESS                 if \a count has been populated.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT  if \a dev or \a count is NULL.
 *         - \ref MTML_ERROR_NOT_SUPPORTED     if the operation is not supported.
 *         - \ref MTML_ERROR_DRIVER_FAILURE    if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD    if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW    if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN           if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceCountFan(const MtmlDevice* dev, unsigned int* count);

/**
 * Retrieves the intended operating speed of the device's specified fan.
 * The reported speed is the intended fan speed. If the fan is physically blocked and unable to spin,
 * the output will not match the actual fan speed.
 *
 * For all discrete products with dedicated fans.
 *
 * The fan speed is expressed as a percentage of the product's maximum noise tolerance fan speed.
 * This value may exceed 100% in certain cases.
 *
 * @param dev                                  [in] The pointer of the target device.
 * @param index                                [in] The index of the target fan, zero indexed.
 * @param speed                                [out] The reference in which to return the fan speed percentage.
 *
 * @return
 *         - \ref MTML_SUCCESS                 if \a speed has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT  if \a dev or \a speed is NULL, or \a index is invalid.
 *         - \ref MTML_ERROR_NOT_SUPPORTED     if the operation is not supported.
 *         - \ref MTML_ERROR_DRIVER_FAILURE    if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD    if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW    if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN           if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceGetFanSpeed(const MtmlDevice* dev, unsigned int index, unsigned int* speed);


/***********************************/
/** @}
 */
/***********************************/



/***************************************************************************************************/
/** @defgroup mtml7 Device Virtualization Functions
 * This group introduces device virtualization functions.
 *  @{
 */
/***************************************************************************************************/

/**
 * Gets the number of all virtualization types supported by a virtualizable device. 
 * This function is ONLY applicable to a device that supports to be virtualized.
 * Refer to \a MtmlDeviceProperty.virtCap to determine whether a device is virtualizable.
 * 
 * For all products.
 * 
 * @param dev                                  [in] The pointer to the target device.
 * @param count                                [out] The reference in which to return the number of supported virtualization types.
 * 
 * @return
 *         - \ref MTML_SUCCESS                 if \a count has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT  if \a dev or \a count is NULL.
 *         - \ref MTML_ERROR_NOT_SUPPORTED     if \a dev is non-virtualizable.
 *         - \ref MTML_ERROR_DRIVER_FAILURE    if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_UNKNOWN           if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceCountSupportedVirtTypes(const MtmlDevice *dev, unsigned int *count);
 
/**
 * Gets the list of virtualization types supported by a virtualizable device. 
 * This function is ONLY applicable to a device that supports to be virtualized.
 * Refer to \a MtmlDeviceProperty.virtCap to determine whether a device is virtualizable.
 * 
 * For all products.
 * 
 * @param dev                                  [in] The pointer to the target device.
 * @param types                                [out] The reference in which to return the supported virtualization types.
 * @param count                                [in] The size of the array pointed by \a types. 
 *
 * @return
 *         - \ref MTML_SUCCESS                 if \a types has been populated.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT  if \a dev or \a types is NULL.
 *         - \ref MTML_ERROR_INSUFFICIENT_SIZE if \a count is too small.
 *         - \ref MTML_ERROR_NOT_SUPPORTED     if \a dev is non-virtualizable.
 *         - \ref MTML_ERROR_DRIVER_FAILURE    if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_UNKNOWN           if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceGetSupportedVirtTypes(const MtmlDevice *dev, MtmlVirtType *types, unsigned int count);
 
/**
 * Gets the number of virtualization types, from which a virtual device can be created, of a virtualizable device. 
 * This function is ONLY applicable to a device that supports to be virtualized.
 * Refer to \a MtmlDeviceProperty.virtCap to determine whether a device is virtualizable.
 * 
 * For all products.
 * 
 * @param dev                                  [in] The pointer to the target device.
 * @param count                                [out] The reference in which to return the number of available virtualization types.
 *                                             
 * @return
 *         - \ref MTML_SUCCESS                 if \a count has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT  if \a dev or \a count is NULL.
 *         - \ref MTML_ERROR_NOT_SUPPORTED     if \a dev is non-virtualizable.
 *         - \ref MTML_ERROR_DRIVER_FAILURE    if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_UNKNOWN           if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceCountAvailVirtTypes(const MtmlDevice *dev, unsigned int *count);
 
/**
 * Gets the list of virtualization types, from which a virtual device can be created, of a virtualizable device.
 * This function is ONLY applicable to a device that supports to be virtualized.
 * Refer to \a MtmlDeviceProperty.virtCap to determine whether a device is virtualizable.
 * 
 * For all products.
 * 
 * @param dev                                  [in] The pointer to the target device.
 * @param types                                [out] The reference in which to return the available virtualization types.
 * @param count                                [in] The size of the array pointed by \a types.
 *
 * @return
 *         - \ref MTML_SUCCESS                 if \a types has been populated.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT  if \a dev or \a types is NULL.
 *         - \ref MTML_ERROR_INSUFFICIENT_SIZE if \a count is too small.
 *         - \ref MTML_ERROR_NOT_SUPPORTED     if \a dev is non-virtualizable.
 *         - \ref MTML_ERROR_DRIVER_FAILURE    if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_UNKNOWN           if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceGetAvailVirtTypes(const MtmlDevice *dev, MtmlVirtType *types, unsigned int count);
 
/**
 * Gets the number of virtual devices that can be created from a specified virtualization type supported by a virtualizable device.
 * This function is ONLY applicable to a device that supports to be virtualized.
 * Refer to \a MtmlDeviceProperty.virtCap to determine whether a device is virtualizable.
 * 
 * For all products.
 * 
 * @param dev                                  [in] The pointer to the target device.
 * @param type                                 [in] The specified virtualization type.
 * @param count                                [out] The reference in which to return the number of available virtualization types.
 * 
 * @return
 *         - \ref MTML_SUCCESS                 if \a count has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT  if \a dev or \a type or \a count is NULL.
                                               or \a type is invalid or not supported.
 *         - \ref MTML_ERROR_NOT_SUPPORTED     if \a dev is non-virtualizable.
 *         - \ref MTML_ERROR_DRIVER_FAILURE    if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_UNKNOWN           if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceCountAvailVirtDevices(const MtmlDevice *dev, const MtmlVirtType *type, unsigned int *count);
 
/**
 * Gets the number of active virtual devices created on a virtualizable device. 
 * A virtual device is active if it has been allocated resources as per its virtualization type.
 * This function is ONLY applicable to a device that supports to be virtualized.
 * Refer to \a MtmlDeviceProperty.virtCap to determine whether a device is virtualizable.
 * 
 * For all products.
 * 
 * @param dev                                  [in] The pointer to the target device.
 * @param count                                [out] The reference in which to return the number of active virtual devices.
 * 
 * @return
 *         - \ref MTML_SUCCESS                 if \a count has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT  if \a dev or \a count is NULL.
 *         - \ref MTML_ERROR_NOT_SUPPORTED     if \a dev is non-virtualizable.
 *         - \ref MTML_ERROR_DRIVER_FAILURE    if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_UNKNOWN           if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceCountActiveVirtDevices(const MtmlDevice *dev, unsigned int *count);

/**
 * Gets the list of UUIDs of all active virtual devices created on a virtualizable device.
 * The UUID strings are output in the \a uuids parameter, which shall be a pointer to a continuous memory block whose size is enough to
 * all content. The memory block is treated as a series of head-tail adjacent buffers (entry), while each of the buffer is \a entryLength
 * bytes in size. The number of the buffers is defined by \a entryCount, thus the total size of the memory block pointed by \a uuids shall
 * be equal or greater than \a entryLength * \a entryCount. Each buffer within the memory block is responsible for holding one UUID string with a
 * null-terminator, so it's the caller's responsibility to ensure there are enough buffers to hold all UUID strings and also each buffer is
 * enough in size to hold a single UUID string.
 * If the \a entryCount is greater than the actual number of active virtual devices, the extra entries are filled with empty strings.
 * A virtual device is active if it has been allocated resources as per its virtualization type. 
 * This function is ONLY applicable to a device that supports to be virtualized.
 * Refer to \a MtmlDeviceProperty.virtCap to determine whether a device is virtualizable.
 * 
 * For all products.
 * 
 * @param dev                                  [in] The pointer to the target device.
 * @param uuids                                [out] A pointer to the memory block tha holds all ouput UUID strings.
 * @param entryLength                          [in] The size of each entry (each buffer) in \a uuids.
 * @param entryCount                           [in] The number of entries in \a uuids.
 * 
 * @return
 *         - \ref MTML_SUCCESS                 if \a uuids has been populated.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT  if \a dev or \a uuids is NULL.
 *         - \ref MTML_ERROR_INSUFFICIENT_SIZE if \a entrylength or \a entryCount is too small.
 *         - \ref MTML_ERROR_NOT_SUPPORTED     if \a dev is non-virtualizable.
 *         - \ref MTML_ERROR_DRIVER_FAILURE    if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_UNKNOWN           if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceGetActiveVirtDeviceUuids(const MtmlDevice *dev, char *uuids, unsigned int entryLength, unsigned int entryCount);

/**
 * Retrieves the maximum number of vGPU devices creatable on a device for given vGPU type.
 *
 * For all products.
 *
 * @param dev                                  [in] The identifier of the target device.
 * @param type                                 [in] Handle to vGPU type.
 * @param virtDevicesCount                     [out] Pointer to get the max number of vGPU instances,
 *                                             which can be created on a deicve for given vgpuTypeId.
 * @return
 *         - \ref MTML_SUCCESS                 successful completion.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT  if \a type is invalid, or is not supported on target device,
 *                                             or \a dev or \a virtDeviceCount is NULL.
 *         - \ref MTML_ERROR_NOT_SUPPORTED     if \a dev is not a virtual device.
 *         - \ref MTML_ERROR_DRIVER_FAILURE    if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_UNKNOWN           on any unexpected error.
 */
MtmlReturn MTML_API mtmlDeviceCountMaxVirtDevices(const MtmlDevice* dev, const MtmlVirtType* type, unsigned int* virtDevicesCount);
 
/**
 * Initializes an active virtual device that can be specified by the UUID from a virtualizable device. 
 * A virtual device is active if it has been allocated resources as per its virtualization type.
 * This function is ONLY applicable to a device that supports to be virtualized.
 * Refer to \a MtmlDeviceProperty.virtCap to determine whether a device is virtualizable.
 * The output data is allocated internally by the MTML library. Use \ref mtmlDeviceFreeVirtDevice() to release it resources
 * when it is not needed any longer.
 * 
 * For all products.
 * 
 * @warning Providing this function with a \a virtDev that has already been initialized causes memory leak.
 * 
 * @param dev                                  [in] The pointer to the target device.
 * @param uuid                                 [in] The UUID string of a virtual device.
 * @param virtDev                              [out] The double pointer to the memory opaque object that shall be allocated and initialized.
 *
 * @return
 *         - \ref MTML_SUCCESS                 if \a virtDev has been initialized.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT  if \a dev or \a uuid or \a virtDev is NULL.
 *         - \ref MTML_ERROR_NOT_SUPPORTED     if \a dev is non-virtualizable.
 *         - \ref MTML_ERROR_INSUFFICIENT_MEMORY if the system is running out of memory.
 *         - \ref MTML_ERROR_NOT_FOUND         if there is no Virtual Device found with \a uuid.
 *         - \ref MTML_ERROR_DRIVER_FAILURE    if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_UNKNOWN           if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceInitVirtDevice(const MtmlDevice *dev, const char *uuid, MtmlDevice **virtDev);

/**
 * Releases the resources managed by the opaque object of a virtual device and makes it unusable. 
 * This function is ONLY applicable to a device that supports to be virtualized.
 * Refer to \a MtmlDeviceProperty.virtCap to determine whether a device is virtualizable.
 * 
 * For all products.
 * 
 * @param virtDev                              [in] The pointer to a device opaque object that shall be freed.
 *                                             
 * @return
 *         - \ref MTML_SUCCESS                      if \a virtDev has been freed.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT       if \a virtDev is NULL or not a virtDev.
 *         - \ref MTML_ERROR_NOT_SUPPORTED          if \a virtDev is not a Virtual Device.
 *         - \ref MTML_ERROR_UNKNOWN                if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceFreeVirtDevice(MtmlDevice *virtDev);
 
/**
 * Gets the virtualization type based on which a virtual device is created.
 * This function is ONLY applicable to virtual devices.
 * A virtual device can be initialized by \ref mtmlDeviceInitVirtDevice() and always has a virtualization role
 * of #MTML_VIRT_ROLE_HOST_VIRTDEVICE. Refer to \ref MtmlVirtRole for more information.
 * 
 * For all products.
 * 
 * @param virtDev                              [in] The pointer to the target virtual device.
 * @param type                                 [out] The reference to which the virtualization type is returned.
 * 
 * @return
 *         - \ref MTML_SUCCESS                 if \a type has been populated.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT  if \a virtDev or \a type is NULL.
 *         - \ref MTML_ERROR_NOT_SUPPORTED     if \a virtDev is not a Virtual Device.
 *         - \ref MTML_ERROR_DRIVER_FAILURE    if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_UNKNOWN           if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceGetVirtType(const MtmlDevice *virtDev, MtmlVirtType *type);

/**
 * Gets the physical device from which a virtual device is created.
 * This function is ONLY applicable to virtual devices.
 * A virtual device can be initialized by \ref mtmlDeviceInitVirtDevice() and always has a virtualization role
 * of #MTML_VIRT_ROLE_HOST_VIRTDEVICE. Refer to \ref MtmlVirtRole for more information.
 * 
 * For all products.
 * 
 * @param virtDev                              [in] The pointer to the target virtual device.
 * @param uuid                                 [out] The reference to which the UUID of the physical device is returned.
 * @param length                               [in] The size of the buffer pointed by \a uuid, in bytes.
 * 
 * @return
 *         - \ref MTML_SUCCESS                 if \a version has been populated.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT  if \a virtDev or \a uuid is NULL.
 *         - \ref MTML_ERROR_NOT_SUPPORTED     if \a virtDev is not a virtual device.
 *         - \ref MTML_ERROR_INSUFFICIENT_SIZE if \a length is too small.
 *         - \ref MTML_ERROR_DRIVER_FAILURE    if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_UNKNOWN           if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlDeviceGetPhyDeviceUuid(const MtmlDevice *virtDev, char *uuid, unsigned int length);

/***********************************/
/** @}
 */
/***********************************/

/***************************************************************************************************/
/** @defgroup mtml8 P2P Functions
 * This group introduces P2P functions.
 *  @{
 */
 /***************************************************************************************************/

/**
 * Retrieves the Topology Level between a given pair of devices.
 * For all products.
 * Supported on Linux only.
 *
 * @param dev1                                 [in] The identifier of the first device.
 * @param dev2                                 [in] The identifier of the second device.
 * @param level                                [out] A \ref mtmlDeviceTopologyLevel that indicates the level.
 *
 * @return
 *         - \ref MTML_SUCCESS                 if \a level has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT  if \a dev1, or \a dev2 is invalid, or \a level is NULL.
 *         - \ref MTML_ERROR_NOT_SUPPORTED     if the device or OS does not support this feature.
 *         - \ref MTML_ERROR_DRIVER_FAILURE    if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_UNKNOWN           an error has occurred in underlying topology discovery.
 */
MtmlReturn MTML_API mtmlDeviceGetTopologyLevel(const MtmlDevice* dev1, const MtmlDevice* dev2, MtmlDeviceTopologyLevel* level);

/**
 * Retrieve the set of device's count that are nearest to a given device at a specific interconnectivity level.
 * For all products.
 * Supported on Linux only.
 *
 * @param dev                                  [in] The identifier of the target device.
 * @param level                                [in] The \ref MtmlDeviceTopologyLevel level to search for other devices.
 * @param count                                [out] The reference in which to return the number of topology nearest devices.
 *
 * @return
 *         - \ref MTML_SUCCESS                 if \a count has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT  if \a dev, or \a level is invalid, or \a count is NULL.
 *         - \ref MTML_ERROR_DRIVER_FAILURE    if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_NOT_SUPPORTED     if the device or OS does not support this feature.
 *         - \ref MTML_ERROR_UNKNOWN           an error has occurred in underlying topology discovery.
 */
MtmlReturn MTML_API mtmlDeviceCountDeviceByTopologyLevel(const MtmlDevice* dev, MtmlDeviceTopologyLevel level, unsigned int* count);

/**
 * Retrieves the set of devices that are nearest to a given device at a specific interconnectivity level.
 * Uses \ref mtmlLibraryFreeDevice() to release resources when not needed any longer.
 * For all products.
 * Supported on Linux only.
 *
 * @param dev                                  [in] The identifier of the target device.
 * @param level                                [in] The \ref MtmlDeviceTopologyLevel level to search for other devices.
 * @param count                                [in] The reference in which to return the number of topology nearest devices, refer to /a mtmlDeviceCountDeviceByTopologyLevel.
 * @param deviceArray                          [out] An array of device handles for devices found at \a level.
 *
 * @return
 *         - \ref MTML_SUCCESS                 if \a deviceArray has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT  if \a dev, \a level, or \a count is invalid, or \a deviceArray is NULL.
 *         - \ref MTML_ERROR_INSUFFICIENT_SIZE if \a count is too small.
 *         - \ref MTML_ERROR_DRIVER_FAILURE    if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_NOT_SUPPORTED     if the device or OS does not support this feature.
 *         - \ref MTML_ERROR_UNKNOWN           an error has occurred in underlying topology discovery.
 */
MtmlReturn MTML_API mtmlDeviceGetDeviceByTopologyLevel(const MtmlDevice* dev, MtmlDeviceTopologyLevel level, unsigned int count, MtmlDevice** deviceArray);

/**
 * Retrieves the status for a given p2p capability between a given pair of devices.
 *
 * @param dev1                                 [in] The first device.
 * @param dev2                                 [in] The second device.
 * @param p2pCap                               [in] P2P capability being looked for between \a dev1 and \a dev2.
 * @param p2pStatus                            [out] Reference in which to return the status of the \a p2pCap
 *                                                         between \a dev1 and \a dev2.
 * @return
 *         - \ref MTML_SUCCESS                    if \a p2pStatus has been populated.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT     if \a dev1 or \a dev2 or \a p2pCap is invalid or \a p2pStatus is NULL.
 *         - \ref MTML_ERROR_NOT_SUPPORTED        if \a dev1 or \a dev2 is virtual device.
 *         - \ref MTML_ERROR_DRIVER_FAILURE       if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_UNKNOWN              on any unexpected error.
 */
MtmlReturn MTML_API mtmlDeviceGetP2PStatus(const MtmlDevice* dev1, const MtmlDevice* dev2, MtmlDeviceP2PCaps p2pCap, MtmlDeviceP2PStatus* p2pStatus);


/***********************************/
/** @}
 */
 /***********************************/



/***************************************************************************************************/
/** @defgroup mtml9 GPU Functions
 * This group introduces GPU functions.
 *  @{
 */
/***************************************************************************************************/

/**
 * Retrieves the current utilization rate for the device's graphic core.
 *
 * For all products.
 *
 * @param gpu                                  [in] The pointer to the GPU opaque object.
 * @param utilization                          [out] The reference in which to return the utilization information.
 * 
 * @return
 *         - \ref MTML_SUCCESS                   if \a utilization has been populated.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT    if \a gpu or \a utilization is NULL.
 *         - \ref MTML_ERROR_DRIVER_FAILURE      if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD      if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW      if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN             if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlGpuGetUtilization(const MtmlGpu *gpu,  unsigned int* utilization);

/**
 * Retrieves the current temperature readings for the device's graphic core, in degrees Celsius. 
 *
 *
 * @param gpu                                  [in] The pointer to the GPU opaque object.
 * @param temp                                 [out] The reference in which to return the temperature reading.
 * 
 * @return
 *         - \ref MTML_SUCCESS                   if \a temp has been populated.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT    if \a gpu or \a temp is NULL.
 *         - \ref MTML_ERROR_DRIVER_FAILURE      if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD      if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW      if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN             if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlGpuGetTemperature(const MtmlGpu *gpu,  unsigned int* temp);


/**
 * Retrieves the current clock speed for the device's graphic core.
 *
 * For all products.
 * 
 * @param gpu                                  [in] The pointer to the GPU opaque object.
 * @param clockMhz                             [out] The reference in which to return the clock speed in MHz.
 * 
 * @return
 *         - \ref MTML_SUCCESS                  if \a clockMhz has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT   if \a gpu or \a clockMhz is NULL.
 *         - \ref MTML_ERROR_DRIVER_FAILURE     if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD     if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW     if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN            if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlGpuGetClock(const MtmlGpu *gpu, unsigned int *clockMhz);

/**
 * Retrieves the maximum supported clock speed for the device's graphic core.
 *
 * For all products.
 * 
 * @param gpu                                  [in] The pointer to the GPU opaque object.
 * @param clockMhz                             [out] The reference in which to return the clock speed in MHz.
 * 
 * @return
 *         - \ref MTML_SUCCESS                  if \a clockMhz has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT   if \a gpu or \a clockMhz is NULL.
 *         - \ref MTML_ERROR_DRIVER_FAILURE     if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD     if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW     if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN            if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlGpuGetMaxClock(const MtmlGpu *gpu, unsigned int *clockMhz);


/***********************************/
/** @}
 */
/***********************************/



/***************************************************************************************************/
/** @defgroup mtml10 Memory Functions
 * This group introduces memory functions.
 *  @{
 */
/***************************************************************************************************/


/**
 * Retrieves the amount of total memory available on the device, in bytes.
 *
 * For all products.
 *
 * @param mem                                 [in] The pointer to the memory opaque object.
 * @param total                               [out] The reference in which to return the total memory size.
 * 
 * @return
 *         - \ref MTML_SUCCESS                   if \a total has been populated.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT    if \a mem is NULL or \a total is NULL.
 *         - \ref MTML_ERROR_DRIVER_FAILURE      if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD      if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW      if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN             if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlMemoryGetTotal(const MtmlMemory *mem, unsigned long long *total);

/**
 * Retrieves the amount of used memory on the device, in bytes.
 *
 * For all products.
 * 
 * @param mem                                [in] The pointer to the memory opaque object.
 * @param used                               [out] The reference in which to return the used memory size.
 * 
 * @return
 *         - \ref MTML_SUCCESS                   if \a used has been populated.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT    if \a mem is NULL or \a used is NULL.
 *         - \ref MTML_ERROR_DRIVER_FAILURE      if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD      if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW      if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN             if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlMemoryGetUsed(const MtmlMemory *mem, unsigned long long *used);

/**
 * Retrieves the current memory utilization rate for the device.
 *
 * For all products.
 * 
 * @param mem                                  [in] The pointer to the memory opaque object.
 * @param utilization                          [out] The reference in which to return the utilization information.
 * 
 * @return
 *         - \ref MTML_SUCCESS                   if \a utilization has been populated.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT    if \a mem or \a utilization is NULL.
 *         - \ref MTML_ERROR_DRIVER_FAILURE      if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD      if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW      if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN             if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlMemoryGetUtilization(const MtmlMemory *mem,  unsigned int *utilization);

/**
 * Retrieves the current clock speed for the memory of a device.
 * 
 * For all products.
 * 
 * @param mem                                  [in] The pointer to the memory opaque object.
 * @param clockMhz                             [out] The reference in which to return the clock speed in MHz.
 * 
 * @return
 *         - \ref MTML_SUCCESS                  if \a clockMhz has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT   if \a mem or \a clockMhz is NULL.
 *         - \ref MTML_ERROR_NOT_SUPPORTED      if the operation is not supported.
 *         - \ref MTML_ERROR_DRIVER_FAILURE     if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD     if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW     if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN            if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlMemoryGetClock(const MtmlMemory *mem, unsigned int *clockMhz);

/**
 * Retrieves the maximum supported clock speed for the memory of a device.
 * 
 * For all products.
 * 
 * @param mem                                  [in] The pointer to the memory opaque object.
 * @param clockMhz                             [out] The reference in which to return the clock speed in MHz.
 * 
 * @return
 *         - \ref MTML_SUCCESS                  if \a clockMhz has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT   if \a mem or \a clockMhz is NULL.
 *         - \ref MTML_ERROR_NOT_SUPPORTED      if the operation is not supported.
 *         - \ref MTML_ERROR_DRIVER_FAILURE     if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD     if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW     if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN            if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlMemoryGetMaxClock(const MtmlMemory *mem, unsigned int *clockMhz);

/**
 * Retrieves the memory bus width of a device.
 *
 * @param mem                                  [in] The identifier of the target device.
 * @param busWidth                             [out] The memory bus width of the device.
 *
 * @return
 *         - \ref MTML_SUCCESS                  if the memory bus width is successfully retrieved.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT   if \a mem or \a busWidth is NULL.
 *         - \ref MTML_ERROR_DRIVER_FAILURE     if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD     if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW     if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN            if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlMemoryGetBusWidth(const MtmlMemory* mem, unsigned int* busWidth);

/***********************************/
/** @}
 */
/***********************************/



/***************************************************************************************************/
/** @defgroup mtml11 VPU Functions
 * This group introduces VPU functions.
 *  @{
 */
/***************************************************************************************************/

/**
 * Retrieves the current utilization rates for the specified VPU.
 *
 * For all products.
 *
 * @param vpu                                  [in] The pointer to the VPU opaque object.
 * @param utilization                          [out] The reference in which to return the utilization information.
 * 
 * @return
 *         - \ref MTML_SUCCESS                   if \a utilization has been populated.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT    if \a vpu is NULL or \a utilization is NULL.
 *         - \ref MTML_ERROR_NOT_SUPPORTED       if \a vpu points to a virtual VPU.
 *         - \ref MTML_ERROR_DRIVER_FAILURE      if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD     if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW     if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN             if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlVpuGetUtilization(const MtmlVpu *vpu,  MtmlCodecUtil *utilization);

/**
 * Retrieves the current clock speed for the specified VPU.
 *
 * For all products.
 * 
 * @param vpu                                  [in] The pointer to the VPU opaque object.
 * @param clockMhz                             [out] The reference in which to return the clock speed in MHz.
 * 
 * @return
 *         - \ref MTML_SUCCESS                  if \a clockMhz has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT   if \a vpu or \a clockMhz is NULL.
 *         - \ref MTML_ERROR_NOT_SUPPORTED      if \a vpu points to a virtual VPU.
 *         - \ref MTML_ERROR_DRIVER_FAILURE     if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD     if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW     if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN            if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlVpuGetClock(const MtmlVpu *vpu, unsigned int *clockMhz);

/**
 * Retrieves the maximum supported clock speed for the specified VPU.
 *
 * For all products.
 * 
 * @param vpu                                  [in] The pointer to the VPU opaque object.
 * @param clockMhz                             [out] The reference in which to return the clock speed in MHz.
 * 
 * @return
 *         - \ref MTML_SUCCESS                  if \a clockMhz has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT   if \a vpu or \a clockMhz is NULL.
 *         - \ref MTML_ERROR_NOT_SUPPORTED      if \a vpu points to a virtual VPU.
 *         - \ref MTML_ERROR_DRIVER_FAILURE     if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD     if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW     if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN            if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlVpuGetMaxClock(const MtmlVpu *vpu, unsigned int *clockMhz);

/**
 * Retrieves the capacity, that is, maximum number of supported concurrent codec sessions, of the specified VPU. 
 * A codec session is the processing of an independent video stream, which can be categorized into an encoder 
 * session and a decoder session. An encoder session refers to the video encoding processing, while a decoder 
 * session represents the decoding processing.
 *  
 * An encoder session can be referred by its ID (session ID), which ranges from 0 to \a encodeCapacity - 1.
 * A decoder session can be referred by its ID (session ID), which ranges from 0 to \a decodeCapacity - 1.
 *
 * For all products.
 * 
 * @param vpu                                  [in] The pointer to the VPU opaque object.
 * @param encodeCapacity                       [out] The reference in which to return the concurrent session capacity for encoding.
 * @param decodeCapacity                       [out] The reference in which to return the concurrent session capacity for decoding.
 * 
 * @return
 *         - \ref MTML_SUCCESS                  if \a encodeCapacity or \a decodeCapacity has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT   if \a vpu or \a encodeCapacity or \a decodeCapacity is NULL.
 *         - \ref MTML_ERROR_DRIVER_FAILURE     if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD     if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW     if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN            if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlVpuGetCodecCapacity(const MtmlVpu *vpu, unsigned int *encodeCapacity, unsigned int *decodeCapacity);

/**
 * Retrieves the state of each encoder session on a specified VPU. The output \a states is an array of \ref MtmlCodecSessionState, 
 * in which each element represents the state of a single encoder session. The state of an encoder session is populated at the
 * position where the array index equals the session ID, that is, \a states[x] will be the state of encoder session x.
 * If the size of the \a states array N is less than the encoder session capacity, the state of the first N (i.e., session IDs
 * ranging from 0 to N-1) sessions will be returned. Otherwise, if N is greater than the encoder session capacity, 
 * the extra space of the \a states array will be populated with MTML_CODEC_SESSION_STATE_UNKNOWN. The encoder session capacity of a VPU can 
 * be retrieved from \ref mtmlVpuGetCodecCapacity(), which can be used as the proper size for the \a states array to hold the 
 * state of all encoder sessions.
 * 
 * For all products.
 * 
 * @param vpu                                  [in] The pointer to the VPU opaque object.
 * @param states                               [out] The reference in which to return the state of encoder sessions.
 * @param length                               [in] The size of the \a state array.
 * 
 * @return
 *         - \ref MTML_SUCCESS                  if \a states has been populated.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT   if \a vpu or \a states is NULL.
 *         - \ref MTML_ERROR_INSUFFICIENT_SIZE  if \a length is 0.
 *         - \ref MTML_ERROR_DRIVER_FAILURE     if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD     if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW     if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN            if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlVpuGetEncoderSessionStates(const MtmlVpu *vpu, MtmlCodecSessionState *states, unsigned int length);

/**
 * Retrieves the metrics of the specified encoder session. If the session is not active (there is no system 
 * process attached to the session), the pid field of the output \a metrics struct is set to zero. Otherwise, 
 * the session is considered active and the output \a metrics struct is populated with valid data.
 * 
 * @note The latency field in the output struct is always 0 for this version.
 * @note In case that the \a vpu argument is a virtual VPU, the pid field in the output 
 *       struct is always 0 for this version.
 *
 * For all products.
 * 
 * @param vpu                                  [in] The pointer to the VPU opaque object.
 * @param sessionId                            [in] The ID of the session whose metrics shall be queried.
 * @param metrics                              [out] The pointer to the output struct to hold the session metrics.
 * 
 * @return
 *         - \ref MTML_SUCCESS                  if \a metrics has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT   if \a vpu or \a metrics is NULL, or \a sessionId is invalid.
 *         - \ref MTML_ERROR_DRIVER_FAILURE     if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD     if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW     if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN            if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlVpuGetEncoderSessionMetrics(const MtmlVpu *vpu, unsigned int sessionId, MtmlCodecSessionMetrics *metrics);

/**
 * Retrieves the state of each decoder session on a specified VPU. The output \a states is an array of \ref MtmlCodecSessionState, 
 * in which each element represents the state of a single decoder session. The state of an decoder session is populated at the
 * position where the array index equals the session ID, that is, \a states[x] will be the state of decoder session x.
 * If the size of the \a states array N is less than the decoder session capacity, the state of the first N (i.e., session IDs
 * ranging from 0 to N-1) sessions will be returned. Otherwise, if N is greater than the decoder session capacity, 
 * the extra space of the \a states array will be populated with MTML_CODEC_SESSION_STATE_UNKNOWN. The decoder session capacity of a VPU can 
 * be retrieved from \ref mtmlVpuGetCodecCapacity(), which can be used as the proper size for the \a states array to hold the 
 * state of all decoder sessions.
 * 
 * For all products.
 * 
 * @param vpu                                  [in] The pointer to the VPU opaque object.
 * @param states                               [out] The reference in which to return the state of decoder sessions.
 * @param length                               [in] The size of the \a state array.
 * 
 * @return
 *         - \ref MTML_SUCCESS                  if \a states has been populated.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT   if \a vpu or \a states is NULL.
 *         - \ref MTML_ERROR_INSUFFICIENT_SIZE  if \a length is 0.
 *         - \ref MTML_ERROR_DRIVER_FAILURE     if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD     if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW     if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN            if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlVpuGetDecoderSessionStates(const MtmlVpu *vpu, MtmlCodecSessionState *states, unsigned int length);

/**
 * Retrieves the metrics of the specified decoder session. If the session is not active (there is no system 
 * process attached to the session), the pid field of the output \a metrics struct is set to zero. Otherwise, 
 * the session is considered active and the output \a metrics struct is populated with valid data.
 * 
 * @note The latency field in the output struct is always 0.
 * @note In case that the \a vpu argument is a virtual VPU, the pid field in in the output  
 *       struct is always 0 for this version.
 *
 * For all products.
 * 
 * @param vpu                                  [in] The pointer to the VPU opaque object.
 * @param sessionId                            [in] The ID of the session whose metrics shall be queried.
 * @param metrics                              [out] The pointer to the output struct to hold the session metrics.
 * 
 * @return
 *         - \ref MTML_SUCCESS                  if \a metrics has been set.
 *         - \ref MTML_ERROR_INVALID_ARGUMENT   if \a vpu or \a metrics is NULL, or \a sessionId is invalid.
 *         - \ref MTML_ERROR_DRIVER_FAILURE     if any error occurred when accessing the driver.
 *         - \ref MTML_ERROR_DRIVER_TOO_OLD     if the driver version is too old.
 *         - \ref MTML_ERROR_DRIVER_TOO_NEW     if the driver version is too new.
 *         - \ref MTML_ERROR_UNKNOWN            if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlVpuGetDecoderSessionMetrics(const MtmlVpu *vpu, unsigned int sessionId, MtmlCodecSessionMetrics *metrics);


/***********************************/
/** @}
 */
/***********************************/


/***************************************************************************************************/
/** @defgroup mtml12 Logging Functions
 * This group introduces logging functions.
 *  @{
 */
/***************************************************************************************************/

/**
 * Configures the MTML logger.
 *
 * @param configuration                         [in] The configuration of the MTML logger.
 * @return
 *          - \ref MTML_SUCCESS                 if MTML's logger has been configured.
 *          - \ref MTML_ERROR_INVALID_ARGUMENT  if \a level is illegal.
 *          - \ref MTML_ERROR_NOT_SUPPORTED     if file is not available.
 *          - \ref MTML_ERROR_UNKNOWN           if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlLogSetConfiguration(const MtmlLogConfiguration *configuration);
 
 
/**
 * Gets the configuration of the MTML logger.
 *
 * @param configuration                         [out] The configuration of MTML logger.
 * @return
 *          - \ref MTML_SUCCESS                 if the configuration of the MTML logger has been get.
 *          - \ref MTML_ERROR_UNKNOWN           if any unexpected error occurred.
 */
MtmlReturn MTML_API mtmlLogGetConfiguration(MtmlLogConfiguration *configuration);

/***********************************/
/** @}
 */
/***********************************/

/***************************************************************************************************/
/** @defgroup mtml13 Error Reporting
 * This group introduces helper functions for error reporting routines.
 *  @{
 */
 /***************************************************************************************************/

/**
 * Helper method for converting MTML error codes into readable strings.
 *
 * For all products.
 *
 * @param result                               MTML error code to convert.
 *
 * @return String representation of the error.
 *
 */
const MTML_API char* mtmlErrorString(MtmlReturn result);

/***********************************/
/** @}
 */
 /***********************************/

#ifdef __cplusplus
}   // extern "C"
#endif

#endif // MTML_H_
